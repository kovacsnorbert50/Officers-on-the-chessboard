#ifndef FIGURETABLE_H
#define FIGURETABLE_H

#include <iostream>

using namespace std;


class FigureTable
{
public:
    FigureTable();
    void generateFigureTable(int);
    void printFigureTable(int);
    void setContent(int, int);
    int getContent(int, int);
    void figureChanged(int);
    void sizeChanged(int);
    void deleteOnIndex(int, int, int);
private:
    int **table;
};

#endif // FIGURETABLE_H
