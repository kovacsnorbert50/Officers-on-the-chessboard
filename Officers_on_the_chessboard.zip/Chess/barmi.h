#ifndef BARMI_H
#define BARMI_H

#include <QMainWindow>
#include <QWidget>
#include <QMainWindow>
#include <QObject>
#include <QApplication>
#include <iostream>

QT_BEGIN_NAMESPACE
namespace Ui { class barmi; }
QT_END_NAMESPACE

class barmi: QMainWindow
{
    Q_OBJECT
public:
    barmi();
};

#endif // BARMI_H
