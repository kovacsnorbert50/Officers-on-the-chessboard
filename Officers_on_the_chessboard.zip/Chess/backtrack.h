#ifndef BACKTRACK_H
#define BACKTRACK_H

#include "teacherchess.h"
#include "chess.h"

class Backtrack
{
public:
    Backtrack();
};

#endif // BACKTRACK_H
