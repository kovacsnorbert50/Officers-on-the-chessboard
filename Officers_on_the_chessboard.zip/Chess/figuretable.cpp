#include "figuretable.h"

FigureTable::FigureTable()
{

}

void FigureTable::generateFigureTable(int size){
    table = new int*[size+1];
    for(int i = 1; i <= size; ++i){
        table[i] = new int[size+1]{0}; //matrix inicializalasa 0-ra
    }
}

void FigureTable::printFigureTable(int size){
    for(int i = 1; i <= size; ++i){
        for(int j = 1; j <= size; ++j){
            cout<<table[i][j]<<"  ";
        }
        cout<<endl;
    }
    cout<<endl;
}

void FigureTable::setContent(int i, int j){
    table[i][j] = 1;
}

int FigureTable::getContent(int i, int j){
    return table[i][j];
}

void FigureTable::figureChanged(int size){
    for(int i = 1 ; i <= size ; ++i){
        for(int j = 1 ; j <= size ; ++j){
            table[i][j] = 0;
        }
    }
}

void FigureTable::sizeChanged(int size){
    for(int i = 1 ; i <= size ; ++i)
        delete table[i];
}

void FigureTable::deleteOnIndex(int size, int x, int y){
    for(int i = 1 ; i <= size ; ++i){
        for(int j = 1 ; j <= size ; ++j){
            if(i == x && j == y){
                table[i][j] = 0;
            }
        }
    }
}

