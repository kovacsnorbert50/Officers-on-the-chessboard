#ifndef MODEWINDOW_H
#define MODEWINDOW_H

QT_BEGIN
namespace Ui { class ModeWindow; }
QT_END_NAMESPACE

class ModeWindow: public QMainWindow
{
    Q_OBJECT
public:
    ModeWindow();
};

#endif // MODEWINDOW_H
