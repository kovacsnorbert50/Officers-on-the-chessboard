#include "modeswindow.h"

ModesWindow::ModesWindow(QWidget *parent):
    QMainWindow (parent)
{
    setWindowTitle("OFFICERS ON THE CHESSBOARD");
    setFixedSize(670,680);

    mainLayoutMainWindow = new QVBoxLayout;

    mainText = new QLabel();
    mainText->setWordWrap(true);
    //Ez egy olyan logikai jatek, ahol a jatekos fel kell helyezze a leheto legtobb egyforma figurat ugy a tablara, hogy azok ne ussek egymast.
    //A tanar uzemmod bemutatja az osszes lehetseges megoldasat a jateknak es vizualizalja a megoldasok szamat, a felhelyezett figurak fuggvenyeben.
    mainText->setText("Welcome to the software!\n\n"
                      "This is a logic game where the player has to place as many identical officers as he can on the chessboard, without any of them hiting another chess-piece."
                      "In the teacher mode every possible solution is presented. This mode visualizes the number of possible solutions, depending on the number of chess-pieces."
                      "\n\n"
                      "CHOOSE A MODE !");
    mainText->setFixedWidth(250);
    mainText->setAlignment(Qt::AlignCenter);
    mainText->setContentsMargins(0,0,0,50);

    mainLayoutMainWindow->addWidget(mainText);

    studentBtn = new QPushButton("STUDENT MODE");
    studentBtn->setFixedWidth(250);
    connect(studentBtn, SIGNAL(clicked()), this, SLOT(onStudentButtonClicked()));

    teacherBtn = new QPushButton("TEACHER MODE");
    teacherBtn->setFixedWidth(250);
    connect(teacherBtn, SIGNAL(clicked()), this, SLOT(onTeacherButtonClicked()));

    mainLayoutMainWindow->addWidget(studentBtn);
    mainLayoutMainWindow->addWidget(teacherBtn);

    mainLayoutMainWindow->setAlignment(Qt::AlignCenter);

    QWidget * w = new QWidget();
        w->setLayout(mainLayoutMainWindow);
        setCentralWidget(w);
}

void ModesWindow::onStudentButtonClicked(){
    Chess *studentWindow = new Chess;
    studentWindow->show();
    hide(); //regi window eltuntetese
}

void ModesWindow::onTeacherButtonClicked(){
    TeacherChess *teacherWindow = new TeacherChess;
    teacherWindow->show();
    hide(); //regi window eltuntetese

}
