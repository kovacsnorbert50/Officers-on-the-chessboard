#include "variantstable.h"

VariantsTable::VariantsTable()
{

}

void VariantsTable::generateVariantsTable(int size, int numberOfVariants){
    variantsTable = new int**[size+1];
    for(int i = 1; i <= size; ++i){
        variantsTable[i] = new int*[size+1];
        for(int j = 1; j <= size; ++j){
            variantsTable[i][j] = new int[numberOfVariants+1];
            for(int k = 1; k <= numberOfVariants; ++k){
                variantsTable[i][j][k] = 0;  //kezdeti inicializalas
            }
        }
    }
}

void VariantsTable::printVariantsTable(int size, int k){
    for(int i = 1; i <= size; ++i){
        for(int j = 1; j <= size; ++j){
            cout<<variantsTable[i][j][k]<<"  ";
        }
        cout<<endl;
    }
    cout<<endl;
}

void VariantsTable::setContent(int i, int j, int k){
    variantsTable[i][j][k] = 1;
}

int VariantsTable::getContent(int i, int j, int k){
    return variantsTable[i][j][k];
}

void VariantsTable::figureOrSizeChanged(int size, int numberOfVariants){
    if(numberOfVariants == 0){
        numberOfVariants = 1; //ha 0 variacio van , akkor kitoroljuk az elso tablat hogy azt jelenitsuk meg a racson(vagyis az ures racsot)
    }
    for(int i = 1 ; i <= size ; ++i){
        for(int j = 1 ; j <= size ; ++j){
            for(int k = 1 ; k <= numberOfVariants ; ++k){
                variantsTable[i][j][k] = 0;
            }
        }
    }
}

