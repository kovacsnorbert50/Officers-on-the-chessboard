#include "visualization.h"

Visualization::Visualization(QWidget *parent, int chessboardSize, int figureInd):
    QMainWindow(parent)
{
    this->chessBoardSize = chessboardSize;
    this->figureIndex = figureInd;

    figureTable = new FigureTable();
    figureTable->generateFigureTable(13);

    checkNumberOfVariants();

    variantsTable = new VariantsTable();
    variantsTable->generateVariantsTable(13, 282000);

    backTracking();

    setWindowTitle("OFFICERS ON THE CHESSBOARD");

    mainLayout = new QVBoxLayout;

    //legelso vizszintes
    firstTopLayout = new QHBoxLayout;

    text = new QLabel;
    text->setText("In this grid you can see the number of possible variants, depending on the marked grid elements");
    firstTopLayout->addWidget(text);
    firstTopLayout->setAlignment(Qt::AlignCenter);

    //racs
    gridLayout = new QGridLayout;
    gridLayout->setSpacing(0); //racsok kozti hezag
    gridLayout->setAlignment(Qt::AlignCenter);
    generateGrid();

    //also layout
    bottomLayout = new QHBoxLayout;

    backBtn = new QPushButton("BACK TO TEACHER MODE");
    backBtn->setFixedWidth(200);
    connect(backBtn, SIGNAL(clicked()), this, SLOT(onBackButtonClicked()));

    bottomLayout->addWidget(backBtn);
    bottomLayout->setAlignment(Qt::AlignCenter);

    mainLayout->addLayout(firstTopLayout);
    mainLayout->addLayout(gridLayout);
    mainLayout->addLayout(bottomLayout);

    QWidget * w = new QWidget();
        w->setLayout(mainLayout);
        setCentralWidget(w);

}

void Visualization::generateGrid(){
    buttons.resize(chessBoardSize+1);
    for(int i = 1 ; i <= chessBoardSize ; ++i){
        buttons[i].resize(chessBoardSize+1);
        for(int j = 1 ; j <= chessBoardSize ; ++j){
            buttons[i][j] = new GridButton;
            buttons[i][j]->setParent(this);
            buttons[i][j]->setFixedSize(70, 70);
            gridLayout->setSpacing(0);
            gridLayout->addWidget(buttons[i][j], i, j);

            figureTable->figureChanged(chessBoardSize); //figureTable lenullazasa
            figureTable->setContent(i, j); //aktualis racs behelyezese figureTable-be
            int c = countNumberOfVariants();

            buttons[i][j]->setText(QString::number(c));
            if(QString::number(c).size() > 4){
                buttons[i][j]->setStyleSheet("color: yellow; font-size: 18px;");
            }
            else{
                buttons[i][j]->setStyleSheet("color: yellow; font-size: 25px;");
            }

            if(buttons[i][j]->text() == "0"){
                buttons[i][j]->setEnabled(false);
            }

            connect(buttons[i][j], &QPushButton::clicked, [=](){onButtonClicked(i,j);});
        }
    }
    figureTable->figureChanged(chessBoardSize); //figureTable lenullazasa
}

void Visualization::onButtonClicked(int x, int y){
    figureTable->setContent(x, y); //kattintott racs behleyzese a figureTable-ba
    if(buttons[x][y]->text() == "X"){  //ha megegyszer rakattintunk, akkor kitorlodik
        figureTable->deleteOnIndex(chessBoardSize, x, y);
    }
    for(int i = 1 ; i <= chessBoardSize ; ++i){
        for(int j = 1 ; j <= chessBoardSize ; ++j){
            if(figureTable->getContent(i, j) != 1){
                figureTable->setContent(i, j); //aktualis racs behleyzese a figureTable-ba
                int c = countNumberOfVariants();
                buttons[i][j]->setText(QString::number(c));
                if(QString::number(c).size() > 4){
                    buttons[i][j]->setStyleSheet("color: yellow; font-size: 18px;");
                }
                else{
                    buttons[i][j]->setStyleSheet("color: yellow; font-size: 25px;");
                }
                figureTable->deleteOnIndex(chessBoardSize, i, j);
            }
            if(figureTable->getContent(i, j) == 1){
                buttons[i][j]->setText("X");
                buttons[i][j]->setStyleSheet("color: red; font-size: 25px;");
            }
            if(buttons[i][j]->text() == "0"){
                buttons[i][j]->setEnabled(false);
            }
            if(buttons[i][j]->text() != "0"){
                buttons[i][j]->setEnabled(true);
            }
        }
    }
}

void Visualization::onBackButtonClicked(){
    TeacherChess *teacherWindow = new TeacherChess;
    teacherWindow->show();
    hide(); //regi window eltuntetese
}

int Visualization::countNumberOfVariants(){
    bool ok;
    int count = 0;
    for(int k = 1 ; k <= numOfVariants ; ++k){
        ok = false;
        for(int i = 1 ; i <= chessBoardSize ; ++i){
            for(int j = 1 ; j <= chessBoardSize ; ++j){
                int a = variantsTable->getContent(i, j, k);
                int b = figureTable->getContent(i, j);
                if(a != b && a == 0 && b == 1){
                    ok = true;
                }
            }
        }
        if(ok){//rossz variaciok
        }
        if(ok == false){//megfelelo variaciok
            ++count;
        }
    }
    return count;
}

void Visualization::checkNumberOfVariants(){
    if(figureIndex == 1){
        switch(chessBoardSize){
        case 8:
            numOfVariants = 92;
            break;
        case 7:
            numOfVariants = 40;
            break;
        case 6:
            numOfVariants = 4;
            break;
        case 5:
            numOfVariants = 10;
            break;
        case 4:
            numOfVariants = 2;
            break;
        case 3:
            numOfVariants = 0;
            break;
        }
    }
    if(figureIndex == 2){
        if(chessBoardSize % 2 != 0){
            numOfVariants = 1;
        }
        else{
            if(chessBoardSize == 4){
                numOfVariants = 79;
            }
            if(chessBoardSize == 6){
                numOfVariants = 3600;
            }
            if(chessBoardSize == 8){
                numOfVariants = 281571;
            }
        }
    }
    if(figureIndex == 3){
        switch(chessBoardSize){
        case 8:
            numOfVariants = 40320;
            break;
        case 7:
            numOfVariants = 5040;
            break;
        case 6:
            numOfVariants = 720;
            break;
        case 5:
            numOfVariants = 120;
            break;
        case 4:
            numOfVariants = 24;
            break;
        case 3:
            numOfVariants = 6;
            break;
        }
    }
    if(figureIndex == 4){
        if(chessBoardSize % 2 == 0){
            numOfVariants = 2;
        }
        if(chessBoardSize % 2 != 0){
            numOfVariants = 1;
        }
    }
    if(figureIndex == 5){
        numOfVariants = pow(2, chessBoardSize);
    }
    if(figureIndex == 6){
        switch(chessBoardSize){
        case 10:
            numOfVariants = 4;
            break;
        case 11:
            numOfVariants = 44;
            break;
        case 12:
            numOfVariants = 156;
            break;
        case 13:
            numOfVariants = 1876;
            break;
        }
    }
    if(figureIndex == 7){
        if(chessBoardSize % 2 != 0){
            numOfVariants = 1;
        }
        else{
            switch(chessBoardSize){
            case 4:
                numOfVariants = 25;
                break;
            case 6:
                numOfVariants = 120;
                break;
            case 8:
                numOfVariants = 497;
                break;
            case 10:
                numOfVariants = 1924;
                break;
            }
        }
    }
    if(figureIndex == 8){
        switch(chessBoardSize){
        case 3:
            numOfVariants = 2;
            break;
        case 4:
            numOfVariants = 8;
            break;
        case 5:
            numOfVariants = 20;
            break;
        case 6:
            numOfVariants = 94;
            break;
        case 7:
            numOfVariants = 438;
            break;
        case 8:
            numOfVariants = 2766;
            break;
        case 9:
            numOfVariants = 19480;
            break;
        case 10:
            numOfVariants = 163058;
            break;
        }
    }
    if(figureIndex == 9){
        numOfVariants = pow(2, chessBoardSize) / 4;
    }
}

void Visualization::backTracking(){
    lvl = 1;
    if(figureIndex == 1){
       bt_chess(array, chessBoardSize, 1, queen_attack);
    }
    if(figureIndex == 2){
        q = 0;
        if(chessBoardSize % 2 != 0){
            for(int i = 1; i <= chessBoardSize; ++i){
                for(int j = 1; j <= chessBoardSize; ++j){
                    if(i % 2 != 0 && j % 2 != 0){
                        variantsTable->setContent(i, j, 1);
                    }
                }
            }
        }
        if(chessBoardSize % 2 == 0){
            bt_king(0, 0, 1, 1);
        }
    }
    if(figureIndex == 3){
       bt_chess(array, chessBoardSize, 1, rook_attack);
    }
    if(figureIndex == 4){
        generateKnight();
    }
    if(figureIndex == 5){
        firstCreate();
        solveBishop();
        printTable1();
    }
    if(figureIndex == 6){
       bt_chess(array, chessBoardSize, 1, queenOnKnight_attack);
    }
    if(figureIndex == 7){
        q = 0;
        if(chessBoardSize % 2 != 0){
            for(int i = 1; i <= chessBoardSize; ++i){
                for(int j = 1; j <= chessBoardSize; ++j){
                    if(i % 2 != 0 && j % 2 != 0){
                        variantsTable->setContent(i, j, 1);
                    }
                }
            }
        }
        if(chessBoardSize % 2 == 0){
            bt_king(0, 0, 1, 1);
        }
    }
    if(figureIndex == 8){
       bt_chess(array, chessBoardSize, 1, rookOnKnight_attack);
    }
    if(figureIndex == 9){
        t = 0;
        firstCreate();
        solveBishop();
        bishopOnKnightTest();
    }
}

void Visualization::generateKnight(){
    for(int k = 1 ; k <= numOfVariants ; ++k){
        for(int i = 1 ; i <= chessBoardSize ; ++i){
            for(int j = 1 ; j <= chessBoardSize ; ++j){
                if(k == 1){
                    if(checkColor(i, j) == 1){
                        variantsTable->setContent(i, j, k);
                    }
                }
                if(k == 2 && chessBoardSize % 2 == 0){ // csak akkor ha paros a sakktabla merete , ha paratlan csak a feherekre lehet helyezni
                    if(checkColor(i, j) == -1){
                        variantsTable->setContent(i, j, k);
                    }
                }
            }
        }
    }
}

int Visualization::checkColor(int i, int j){
    //Ha feher racs return 1 , ha fekete racs return -1
    //paratlan sor es paratlan oszlop (feher)
    if(i%2 != 0 && j%2 != 0){
        return 1;
    }
    //paratlan sor es paros oszlop (fekete)
    if(i%2 != 0 && j%2 == 0){
        return -1;
    }
    //paros sor es paratlan oszlop (fekete)
    if(i%2 == 0 && j%2 != 0){
        return -1;
    }
    //paros sor es paros oszlop (feher)
    if(i%2 == 0 && j%2 == 0){
        return 1;
    }
    return 0;
}

//-----------------------------------  XCode BACKTRACKING C++  -------------------------------------------------

//compare fuggvenyek
int Visualization::queen_attack(int i1, int j1, int i2, int j2){
    //sor, oszlop, atlo
    return i1 == i2 || j1 == j2 || abs(i1-i2) == abs(j1-j2);
}

int Visualization::rook_attack(int i1, int j1, int i2, int j2){
    //sor, oszlop
    return i1 == i2 || j1 == j2;
}

int Visualization::queenOnKnight_attack(int i1, int j1, int i2, int j2){
    //sor, oszlop, atlo, lo
    return i1 == i2 || j1 == j2 || abs(i1-i2) == abs(j1-j2) || (abs(i1-i2) == 1 && abs(j1-j2) == 2) || (abs(i1-i2) == 2 && abs(j1-j2) == 1);
}

int Visualization::rookOnKnight_attack(int i1, int j1, int i2, int j2){
    //sor, oszlop, lo
    return i1 == i2 || j1 == j2 || (abs(i1-i2) == 1 && abs(j1-j2) == 2) || (abs(i1-i2) == 2 && abs(j1-j2) == 1);
}

int Visualization::itIsOk1(int *x, int k, int (*figure_attack)(int,int,int,int)){
    for( int i = 1 ; i < k ; ++i ){
        if (figure_attack(i, x[i], k, x[k])) { return 0; }
    }
    return 1;
}

void Visualization::print(int *x, int n){
    for( int i = 1 ; i <= n ; ++i ){
        //printf("(%i,%i)", i, x[i]);
        variantsTable->setContent(i, x[i], lvl); // a 3D tombben valo elhelyezes, variaciok szintenken (lvl)
    }
    //printf("\n");
}

void Visualization::bt_chess(int *x, int n, int k, int (*figure_attack)(int,int,int,int)){
    for( x[k] = 1; x[k] <= n ; ++x[k] ){
        if( itIsOk1(x, k, figure_attack) ){
            if( k == n ){
                print(x, k);
                lvl++;
            }
            else{
                bt_chess(x, n, k+1, figure_attack);
            }
        }
    }
}

// --------------------- King BT ----------------------

void Visualization::printKing(){
    ++q;
    for( int i = 0; i < chessBoardSize ; ++i ){
        for( int j = 0; j < chessBoardSize ; ++j ){
            if(desk[i][j] == 1){
                variantsTable->setContent(i+1, j+1, q);
            }
            //cout << desk[i][j] <<" ";
        }
        //cout << endl;
    }
    //cout << endl;
}

int Visualization::itIsOk2( int x, int y){
    for( int i = -1; i <= 1 ; ++i ){
        for( int j = -1; j <= 1 ; ++j ){
            if( i == 0 && j == 0 ){ continue; }
            if( x+i < 0 || x+i >= chessBoardSize || y+j < 0 || y+j >= chessBoardSize ){ continue; }
            if( desk[x+i][y+j] == 1 ){
                return 0;
            }
        }
    }
    //ha a kiraly a lovon van
    if(figureIndex == 7){
        for (int i = 0; i < chessBoardSize; ++i) {
                for (int j = 0; j < chessBoardSize; ++j) {
                    if(desk[i][j] == 1){
                        if((abs(i-x) == 1 && abs(j-y) == 2) || (abs(i-x) == 2 && abs(j-y) == 1)){
                            return 0;
                        }
                    }
                }
            }
    }
    return 1;
}

void Visualization::bt_king(int ii, int jj, int k, int q){
    for( int i = 0; i < 2 ; ++i ){
        for( int j = 0; j < 2 ; ++j ){
            if( itIsOk2(ii+i,jj+j) ){
                desk[ii+i][jj+j] = 1;
                if( k == chessBoardSize*chessBoardSize/4 ){
                    printKing();
                }
                else{
                    if( jj+2 < chessBoardSize ){
                        bt_king(ii, jj+2, k+1, q);
                    }
                    else{
                        bt_king(ii+2, 0, k+1, q);
                    }
                }
                desk[ii+i][jj+j] = 0;
            }
        }
    }
}

// --------------------- Bishop binary ----------------------

void Visualization::printTable1(){
    for (int k = 0; k < var; ++k) {
        cout<<k<<":"<<endl;
        for( int i = 0; i < n ; ++i ){
            for( int j = 0; j < n ; ++j ){
                if(tabla1[i][j][k] == 1){
                    variantsTable->setContent(i+1, j+1, k+1);
                }
                //cout << tabla1[i][j][k] << ' ';
            }
            //cout << endl;
        }
        //cout << endl;
    }
}

void Visualization::printOneSolution(int k){
    cout<<++t<<":"<<endl;
    for( int i = 0; i < n ; ++i ){
        for( int j = 0; j < n ; ++j ){
            if(tabla1[i][j][k] == 1){
                variantsTable->setContent(i+1, j+1, t);
            }
            //cout << tabla1[i][j][k] << ' ';
        }
        //cout << endl;
    }
    //cout << endl;
}

void Visualization::decToBinary(int a)
{
    int s=-1;
    for(int i=0; i<=32; ++i){
        binaryNum[i] = 0;
        vegso[i] = 0;
    }
    int i = 0;
    while (a > 0) {
        binaryNum[i] = a % 2;
        a = a / 2;
        i++;
    }

    for (int j = n - 1; j >= 0; j--){
        //cout << binaryNum[j];
        vegso[++s] = binaryNum[j];
    }
}

void Visualization::firstCreate(){
    t = 0;
    n = chessBoardSize;
    var = pow(2, n);

    for (int k = 0; k < var; ++k) {
        for( int i = 0; i < n ; ++i ){
            for( int j = 0; j < n ; ++j ){
                tabla1[i][j][k] = 0;
            }
        }
    }

    for (int k = 0; k < var; ++k) {
        for( int i = 0; i < n ; ++i ){
            for( int j = 0; j < n ; ++j ){
                decToBinary(k);
                if (i == n-1) {
                    tabla1[i][j][k] = vegso[j];
                }
            }
        }
    }
}

void Visualization::solveBishop(){
    for (int k = 0; k < var; ++k) {
        for( int i = 0; i < n ; ++i ){
            for( int j = 0; j < n ; ++j ){
                if(i == n-1){
                    if(tabla1[i][j][k] == 1 && j != 0 && j != n-1){
                        tabla1[0][n-1-j][k] = 1;
                    }

                    if(tabla1[i][j][k] == 0){
                        if(j != 0){
                            tabla1[n-1-j][0][k] = 1;
                        }
                        if(j != n-1){
                            tabla1[j][n-1][k] = 1;
                        }
                    }
                }
            }
        }
    }
}

void Visualization::bishopOnKnightTest(){
    int d = 0;
    bool ok;
    for (int k = 0; k < var; ++k) {
        ok =  true;
        for( int i1 = 0; i1 < n ; ++i1 ){
            for( int j1 = 0; j1 < n ; ++j1 ){
                //bal felso sarok
                if((tabla1[0][1][k] == 1 && tabla1[2][0][k] == 1) || (tabla1[0][2][k] == 1 && tabla1[1][0][k] == 1)){
                    ok = false;
                }
                //jobb felso sarok
                if((tabla1[0][n-2][k] == 1 && tabla1[2][n-1][k] == 1) || (tabla1[0][n-3][k] == 1 && tabla1[1][n-1][k] == 1)){
                    ok = false;
                }
                //bal also sarok
                if((tabla1[n-1][1][k] == 1 && tabla1[n-3][0][k] == 1) || (tabla1[n-1][2][k] == 1 && tabla1[n-2][0][k] == 1)){
                    ok = false;
                }
                //jobb also sarok
                if((tabla1[n-1][n-2][k] == 1 && tabla1[n-3][n-1][k] == 1) || (tabla1[n-1][n-3][k] == 1 && tabla1[n-2][n-1][k] == 1)){
                    ok = false;
                }
            }
        }
        if(ok){
            ++d;
            printOneSolution(k);
            //kiir k-adik variacio, kell egy ilyen fuggveny es akkor be tudom tenni a variantsTable-be(szoftverbe)!
        }
    }
    cout<<"Futo a lovon problema, helyes megoldasok szama(2^n / 4): "<<d<<endl;
}

