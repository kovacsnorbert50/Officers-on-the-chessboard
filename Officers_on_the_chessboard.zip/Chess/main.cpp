#include "chess.h"
#include "modeswindow.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    ModesWindow w;
    w.show();
    return a.exec();
}
