#include "gridbutton.h"

GridButton::GridButton(QPushButton *parent) : QPushButton(parent)
{
}
