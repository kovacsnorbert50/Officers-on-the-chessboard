#ifndef VARIANTSTABLE_H
#define VARIANTSTABLE_H

#include <iostream>
#include "figuretable.h"

using namespace std;

class VariantsTable
{
public:
    VariantsTable();
    void generateVariantsTable(int, int);
    void printVariantsTable(int, int);
    void setContent(int, int, int);
    int getContent(int, int, int);
    void figureOrSizeChanged(int, int);
private:
    int ***variantsTable;
};

#endif // VARIANTSTABLE_H
