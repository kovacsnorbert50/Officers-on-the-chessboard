#ifndef XCODEBACKTRACK_H
#define XCODEBACKTRACK_H

#include "chess.h"
#include "teacherchess.h"

class XcodeBacktrack
{
public:
    XcodeBacktrack();
};

#endif // XCODEBACKTRACK_H
