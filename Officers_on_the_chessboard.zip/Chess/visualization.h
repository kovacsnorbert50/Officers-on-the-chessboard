#ifndef VISUALIZATION_H
#define VISUALIZATION_H

#include <QMainWindow>
#include <QWidget>
#include <QMainWindow>
#include <QObject>
#include <QApplication>
#include <QLineEdit>
#include <iostream>
#include <teacherchess.h>

using namespace std;
QT_BEGIN_NAMESPACE
namespace Ui { class Visualization; }
QT_END_NAMESPACE

class Visualization: public QMainWindow
{
    Q_OBJECT
public slots:
    void onBackButtonClicked();
    void onButtonClicked(int, int);
public:
    Visualization(QWidget *parent = nullptr, int chessboardSize = 0, int figureIndex = 0);
    void generateGrid();
    int countNumberOfVariants();
    void checkNumberOfVariants();
    void backTracking();
    void generateKnight();
    int checkColor(int, int);

    //BACKTRACKING C++
    static int queen_attack(int, int, int, int);
    static int rook_attack(int, int, int, int);
    static int queenOnKnight_attack(int, int, int, int);
    static int rookOnKnight_attack(int, int, int, int);

    //QUEEN, ROOK
    int itIsOk1(int *, int, int (*)(int, int, int, int));
    void print(int *, int);
    void bt_chess(int *, int, int, int (*)(int,int,int,int));

    //KING
    void printKing();
    int itIsOk2(int, int);
    void bt_king(int, int, int, int);

    //BISHOP BINARY
    void printTable1();
    void printOneSolution(int);
    void decToBinary(int);
    void firstCreate();
    void solveBishop();
    void bishopOnKnightTest();
private:
    QVBoxLayout *mainLayout;
    QHBoxLayout *firstTopLayout;
    QHBoxLayout *bottomLayout;
    QGridLayout *gridLayout;
    QLineEdit *size;
    QLineEdit *figure;
    QVector<QVector<GridButton*>> buttons;
    QLabel *text;
    QPushButton *backBtn;
    int chessBoardSize;
    int figureIndex;
    int numOfVariants;
    FigureTable *figureTable;
    VariantsTable *variantsTable;
    int lvl;
    int array[100];
    QString whiteColor = "background-color: rgb(255,255,255);" , blackColor = "background-color: rgb(139,69,19);";
    int desk[10][10];
    int q;
    int n = chessBoardSize;
    int tabla1[20][20][65000]{0};
    int var;
    int binaryNum[32]{0};
    int vegso[32]{0};
    int t=0;
};

#endif // VISUALIZATION_H
