#ifndef MODESWINDOW_H
#define MODESWINDOW_H

#include <QMainWindow>
#include <QWidget>
#include <QMainWindow>
#include <QObject>
#include <QApplication>
#include "chess.h"
#include "teacherchess.h"

QT_BEGIN_INCLUDE_NAMESPACE
namespace UI { class ModesWindow;}
QT_END_NAMESPACE

class ModesWindow : public QMainWindow
{
    Q_OBJECT
public slots:
    void onStudentButtonClicked();
    void onTeacherButtonClicked();
public:
    ModesWindow(QWidget *parent = nullptr);
    //~ModesWindow();
private:
    QVBoxLayout *mainLayoutMainWindow;
    QPushButton *studentBtn;
    QPushButton *teacherBtn;
    QLabel *mainText;
};

#endif // MODESWINDOW_H
