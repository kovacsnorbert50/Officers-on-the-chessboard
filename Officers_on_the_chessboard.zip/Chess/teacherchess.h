#ifndef TEACHERCHESS_H
#define TEACHERCHESS_H

#include <QMainWindow>
#include <QWidget>
#include <QMainWindow>
#include <QObject>
#include <QApplication>
#include "chess.h"
#include "variantstable.h"
#include "visualization.h"


QT_BEGIN_NAMESPACE
namespace Ui { class TeacherChess; }
QT_END_NAMESPACE

class TeacherChess: public QMainWindow
{
    Q_OBJECT
public slots:
    void onPreviousButtonClicked();
    void onNextButtonClicked();
    void onStartButtonClicked();
    void onVisualizationButtonClicked();
    void TeacherFigureIndexChanged(int);
    void TeacherSizeIndexChanged();
public:
    TeacherChess(QWidget *parent = nullptr);
    ~TeacherChess();
    void generateGrid();
    void setBackground(int, int, QString, QString);
    int checkColor(int, int);
    void setFinalBackground(int, int);
    void printVariant(int);
    void checkNumberOfVariants();
    void backTracking();
    void generateKnight();

    //BACKTRACKING C++
    static int queen_attack(int, int, int, int);
    static int rook_attack(int, int, int, int);
    static int queenOnKnight_attack(int, int, int, int);
    static int rookOnKnight_attack(int, int, int, int);

    //QUEEN, ROOK
    int itIsOk1(int *, int, int (*)(int, int, int, int));
    void print(int *, int);
    void bt_chess(int *, int, int, int (*)(int,int,int,int));

    //KING
    void printKing();
    int itIsOk2(int, int);
    void bt_king(int, int, int, int);

    //BISHOP BT
    void printBishop();
    int itIsOk3(int, int);
    void bt_bishop(int, int);
    void bt_bishop2(int, int);

    //BISHOP BINARY
    void printTable1();
    void printOneSolution(int);
    void decToBinary(int);
    void firstCreate();
    void solveBishop();
    void bishopOnKnightTest();

private:
    QVBoxLayout *mainLayout;
    QHBoxLayout *firstTopLayout;
    QHBoxLayout *topLayout;
    QGridLayout *gridLayout;
    QHBoxLayout *variantLayout;
    QHBoxLayout *bottomLayout;
    QHBoxLayout *visualizationLayout;
    QLabel *comboFigureText;
    QLabel *comboSizeText;
    QLabel *lcdText;
    QLabel *numberText;
    QLabel *maxText;
    QLabel *maxNumText;
    QComboBox *figure;
    QLineEdit *size;
    QPushButton *startBtn;
    QLCDNumber *numberOfVariants;
    QLCDNumber *variantNumberLcd;
    QPushButton *previousBtn;
    QPushButton *nextBtn;
    QPushButton *visBtn;
    QVector<QVector<GridButton*>> buttons;
    bool buttonClickable = false;
    bool bt1 = true;
    bool bt2 = true;
    FigureTable *figureTable1;
    VariantsTable *variantsTable;
    int figureIndex = 1;
    int chessBoardSize = 8;
    QString whiteColor = "background-color: rgb(255,255,255);" , blackColor = "background-color: rgb(139,69,19);";
    QString firstUrl = " background-image: url(/Users/kovacsnorbert/Desktop/Allamvizsga/Software/Chess/images/";
    QString secondUrl = " background-image: url(/Users/kovacsnorbert/Desktop/Allamvizsga/Software/Chess/images/";
    QString backgroundFigure = "queenB.png);";
    QString finalUrl = "";
    int n = chessBoardSize;
    int array[100];
    int ct;
    int lvl = 1;
    int variantNumber = 1;
    int sizeIndex;
    int numOfVariants;
    bool btnClickable = false;
    int tabla[10][10];
    int tabla1[20][20][65000]{0};
    int q;
    int buttonSize;
    int var;
    int binaryNum[32]{0};
    int vegso[32]{0};
    int t=0;

};

#endif // TEACHERCHESS_H
