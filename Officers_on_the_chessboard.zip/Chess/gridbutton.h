#ifndef GRIDBUTTON_H
#define GRIDBUTTON_H

#include <QPushButton>
#include <QMouseEvent>
#include <QDebug>

class GridButton: public QPushButton
{
    Q_OBJECT
public:
    explicit GridButton(QPushButton *parent = nullptr);

};

#endif // GRIDBUTTON_H
