#ifndef CHESS_H
#define CHESS_H

#include <stdio.h>
#include <time.h>
#include <stdbool.h>
#include <stdlib.h>
#include <iostream>
#include <QPixmap>
#include <QPalette>
#include <QColor>
#include <QLabel>
#include <QLineEdit>
#include <QTextEdit>
#include <QMainWindow>
#include <QString>
#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QPushButton>
#include <QVector>
#include <QString>
#include <QLCDNumber>
#include <QTimer>
#include <QMouseEvent>
#include <QMessageBox>
#include <QComboBox>
#include <QVariant>
#include "gridbutton.h"
#include "figuretable.h"
#include "variantstable.h"

typedef struct{
    int from;
    int to;
    int rowIndex;

}Level;

typedef struct{
    int num;
    int to;
}Wall;

QT_BEGIN_NAMESPACE
namespace Ui { class Chess; }
QT_END_NAMESPACE

class Chess : public QMainWindow
{
    Q_OBJECT
public slots:
    void onStartButtonClicked();
    void onButtonClicked(int, int);
    void onRandomButtonClicked();
    void onHelpButtonClicked();
    void figureIndexChanged(int);
    void sizeIndexChanged();
    void showTime();

public:
    Chess(QWidget *parent = nullptr);
    ~Chess();
    void generateGrid();
    void setBackground(int, int, QString, QString);
    int checkColor(int, int);
    int countNumberOfVariants(VariantsTable*);
    int countNumberOfWallVariants(VariantsTable*, int, int);
    void youWinIf(VariantsTable*, int);
    void setFinalBackground(int, int);
    void checkNumberOfVariants();
    void buttonsNotClickable();
    void buttonsClickable();
    void backTracking();
    void generateKnight();

    //BACKTRACKING C++
    static int queen_attack(int, int, int, int);
    static int rook_attack(int, int, int, int);
    static int queenOnKnight_attack(int, int, int, int);
    static int rookOnKnight_attack(int, int, int, int);

    //QUEEN, ROOK
    int itIsOk1(int *, int, int (*)(int, int, int, int));
    void print(int *, int);
    void bt_chess(int *, int, int, int (*)(int,int,int,int));

    //King
    void printKing();
    int itIsOk2(int, int);
    void bt_king(int, int, int, int);

    //WALL
    Level* buildLevelArray(bool** matrix,int,int*);
    void btQueen(int*,Level*,int,int,int);
    bool itIsOk3(int*,int,Level*);
    bool noColumnBarrier(int,int,int,int);
    bool noDiagonalBarrier(int,int,int,int);
    void printDesk(int*,Level*,int,int);
    void wallVariants(int);

    //BISHOP
    void printBishop();
    int itIsOk4(int, int);
    void bt_bishop(int, int);
    void bt_bishop2(int, int);

    //BISHOP BINARY
    void printTable1();
    void printOneSolution(int);
    void decToBinary(int);
    void firstCreate();
    void solveBishop();
    void bishopOnKnightTest();

private:
    QGridLayout *gridLayout;
    QVBoxLayout *mainLayout;
    QHBoxLayout *firstTopLayout;
    QHBoxLayout *topLayout;
    QHBoxLayout *bottomLayout;
    QComboBox *figure;
    QLineEdit *size;
    QPushButton *startBtn;
    QPushButton *randomBtn;
    QPushButton *helpBtn;
    QLCDNumber *numberOfVariants;
    QLCDNumber *timeC;
    QTimer *timer;
    QVector<QVector<GridButton*>> buttons;
    QLabel *comboFigureText;
    QLabel *comboSizeText;
    QLabel *lcdText;
    QLabel *timerText;
    FigureTable *figureTable;
    bool buttonClickable = false;
    bool bt1 = true;
    bool bt2 = true;
    int time;
    int chessBoardSize = 8;
    int figureIndex = 1;
    int sizeIndex;
    QString whiteColor = "background-color: rgb(255,255,255);" , blackColor = "background-color: rgb(139,69,19);";
    QString firstUrl = " background-image: url(/Users/kovacsnorbert/Desktop/Allamvizsga/Software/Chess/images/";
    QString secondUrl = " background-image: url(/Users/kovacsnorbert/Desktop/Allamvizsga/Software/Chess/images/";
    QString backgroundFigure = "queenB.png);";
    QString finalUrl = "";
    VariantsTable *variantsTable;
    VariantsTable *wallVariantsTable;
    VariantsTable *wallTable;
    VariantsTable *table;
    int lvl = 1;
    int array[100];
    int numOfVariants = 92;
    int h;
    int var;
    int helpCount = 0;
    int desk[10][10];
    int tabla[10][10];
    int q;
    int buttonSize;
    bool** matrix;
    int d = 0;
    int o = 0;
    int v;
    bool checkWall = false;
    int random;
    Wall* wallLevels;
    int tabla1[20][20][65000]{0};
    int n = chessBoardSize;
    int vari;
    int binaryNum[32]{0};
    int vegso[32]{0};
    int t=0;

signals:

};
#endif // CHESS_H
