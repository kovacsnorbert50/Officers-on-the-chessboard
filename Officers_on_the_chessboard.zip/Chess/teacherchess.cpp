#include "teacherchess.h"

TeacherChess::TeacherChess(QWidget *parent)
    :QMainWindow(parent)
{
    finalUrl = firstUrl.append(backgroundFigure); //kezdetben a kiralyno hatterkep

    setWindowTitle("OFFICERS ON THE CHESSBOARD");
    //setFixedSize(670,850);

    //legfelso vizszintes
    firstTopLayout = new QHBoxLayout;

    comboFigureText = new QLabel();
    comboFigureText->setText("CHOOSE A CHESS-PIECE!");
    comboFigureText->setFixedWidth(160);

    comboSizeText = new QLabel();
    comboSizeText->setText("CHOOSE THE CHESSBOARD SIZE!");
    comboSizeText->setFixedWidth(220);

    lcdText = new QLabel();
    lcdText->setText("       NUMBER OF POSSIBLE VARIANTS:");
    lcdText->setFixedWidth(280);

    firstTopLayout->addWidget(comboSizeText);
    firstTopLayout->addWidget(comboFigureText);
    firstTopLayout->addWidget(lcdText);

    //felso vizszintes
    topLayout = new QHBoxLayout;

    figure = new QComboBox(this);
    figure->addItem("QUEEN",QVariant(1));
    figure->addItem("KING",QVariant(2));
    figure->addItem("ROOK",QVariant(3));
    figure->addItem("KNIGHT",QVariant(4));
    figure->addItem("BISHOP",QVariant(5));
    figure->addItem("QUEEN ON KNIGHT",QVariant(6));
    figure->addItem("KING ON KNIGHT",QVariant(6));
    figure->addItem("ROOK ON KNIGHT",QVariant(6));
    figure->addItem("BISHOP ON KNIGHT",QVariant(6));
    figure->setFixedWidth(120);
    connect(figure, SIGNAL(currentIndexChanged(int)), this, SLOT(TeacherFigureIndexChanged(int)));

    size = new QLineEdit;
    size->setFixedWidth(120);
    size->setText("8");
    size->setValidator(new QRegularExpressionValidator(QRegularExpression("[0-9]*")));
    connect(size, SIGNAL(textEdited(QString)), this, SLOT(TeacherSizeIndexChanged()));

    startBtn = new QPushButton("START");
    connect(startBtn, SIGNAL(clicked()), this, SLOT(onStartButtonClicked()));
    startBtn->setFixedWidth(120);

    numberOfVariants = new QLCDNumber(4, this);
    numberOfVariants->display(QString::number(0));
    numberOfVariants->setFixedSize(100,50);
    numberOfVariants->setStyleSheet("background-color : lightblue; color : black;");
    numberOfVariants->setDigitCount(6);

    topLayout->addWidget(size);
    topLayout->addWidget(figure);
    topLayout->addWidget(startBtn);
    topLayout->addWidget(numberOfVariants);

    //racs
    gridLayout = new QGridLayout;
    gridLayout->setAlignment(Qt::AlignCenter);
    gridLayout->setSpacing(0);
    generateGrid();
    //gridLayout->setContentsMargins(40,0,40,0);
    //gridLayout->setVerticalSpacing(0);
    //gridLayout->setHorizontalSpacing(0);

    //utolso elotti vizszintes
    variantLayout = new QHBoxLayout;

    numberText = new QLabel();
    numberText->setText("VARIANT NUMBER:   ");

    variantNumberLcd = new QLCDNumber(4, this);
    variantNumberLcd->display(QString::number(1));
    variantNumberLcd->setFixedSize(70,50);
    variantNumberLcd->setStyleSheet("background-color : lightblue; color : black;");

    maxText = new QLabel();
    maxText->setText("     MAXIMUM NUMBER OF PIECES:  ");

    maxNumText = new QLabel();

    variantLayout->addWidget(numberText);
    variantLayout->addWidget(variantNumberLcd);
    variantLayout->addWidget(maxText);
    variantLayout->addWidget(maxNumText);

    variantLayout->setAlignment(Qt::AlignCenter);

    //also vizszintes
    bottomLayout = new QHBoxLayout;

    previousBtn = new QPushButton("PREVIOUS VARIANT");
    previousBtn->setFixedWidth(250);
    previousBtn->setEnabled(btnClickable);
    connect(previousBtn, SIGNAL(clicked()), this, SLOT(onPreviousButtonClicked()));

    nextBtn = new QPushButton("NEXT VARIANT");
    nextBtn->setFixedWidth(250);
    nextBtn->setEnabled(btnClickable);
    connect(nextBtn, SIGNAL(clicked()), this, SLOT(onNextButtonClicked()));

    bottomLayout->addWidget(previousBtn);
    bottomLayout->addWidget(nextBtn);

    //vizualizacio layout
    visualizationLayout = new QHBoxLayout;

    visBtn = new QPushButton("VISUALIZATION");
    visBtn->setFixedWidth(250);
    connect(visBtn, SIGNAL(clicked()), this, SLOT(onVisualizationButtonClicked()));

    visualizationLayout->addWidget(visBtn);

    //fo fuggoleges
    mainLayout = new QVBoxLayout;
    mainLayout->addLayout(firstTopLayout);
    mainLayout->addLayout(topLayout);
    mainLayout->addLayout(gridLayout);
    mainLayout->addLayout(variantLayout);
    mainLayout->addLayout(bottomLayout);
    mainLayout->addLayout(visualizationLayout);

    QWidget * w = new QWidget();
        w->setLayout(mainLayout);
        setCentralWidget(w);

    checkNumberOfVariants(); //variaciok megszamolasa

    variantsTable = new VariantsTable();
    variantsTable->generateVariantsTable(13, 282000); //legnagyobb size 13 x 13

    backTracking();
}

void TeacherChess::generateGrid(){
    if(chessBoardSize <= 8){
        buttonSize = 70;
    }
    if(chessBoardSize > 8){
        buttonSize = 55;
    }
    buttons.resize(chessBoardSize+1);
    for(int i = 1 ; i <= chessBoardSize ; ++i){
        buttons[i].resize(chessBoardSize+1);
        for(int j = 1 ; j <= chessBoardSize ; ++j){
            buttons[i][j] = new GridButton;
            buttons[i][j]->setParent(this);

            if(i == chessBoardSize){
                buttons[i][j]->setFixedSize(buttonSize, buttonSize-7);
            }
            else{
                buttons[i][j]->setFixedSize(buttonSize, buttonSize);
            }

            gridLayout->addWidget(buttons[i][j], i, j);
            buttons[i][j]->setEnabled(buttonClickable);

            if(checkColor(i,j) == 1){
                setBackground(i, j, whiteColor, "");
            }
            if(checkColor(i,j) == -1){
                setBackground(i, j, blackColor, "");
            }

        }
    }
}

TeacherChess::~TeacherChess()
{
    delete firstTopLayout;
    delete topLayout;
    delete gridLayout;
    delete bottomLayout;
    delete mainLayout;
}

int TeacherChess::checkColor(int i, int j){
    //Ha feher racs return 1 , ha fekete racs return -1
    //paratlan sor es paratlan oszlop (feher)
    if(i%2 != 0 && j%2 != 0){
        return 1;
    }
    //paratlan sor es paros oszlop (fekete)
    if(i%2 != 0 && j%2 == 0){
        return -1;
    }
    //paros sor es paratlan oszlop (fekete)
    if(i%2 == 0 && j%2 != 0){
        return -1;
    }
    //paros sor es paros oszlop (feher)
    if(i%2 == 0 && j%2 == 0){
        return 1;
    }
    return 0;
}

void TeacherChess::setBackground(int i, int j, QString whiteOrBlack, QString fig){
    QString background = whiteOrBlack;
    background.append(fig);
    buttons[i][j]->setStyleSheet(background);
}

void TeacherChess::setFinalBackground(int i, int j){
    if(checkColor(i,j) == 1){
        setBackground(i, j, whiteColor, finalUrl);
    }
    if(checkColor(i,j) == -1){
        setBackground(i, j, blackColor, finalUrl);
    }
}

void TeacherChess::TeacherFigureIndexChanged(int index){
    previousBtn->setEnabled(btnClickable);
    nextBtn->setEnabled(btnClickable);

    variantNumber = 1;
    variantNumberLcd->display(QString::number(variantNumber));

    figureIndex = index + 1;

    TeacherSizeIndexChanged(); //racs uritese figura valtas eseten
}

void TeacherChess::TeacherSizeIndexChanged(){
    startBtn->setEnabled(true);

    int s = size->text().toInt();
    bool ok = true;

    //jatek vege utan nem szamol ismet backtrack-et mert minden ugyanaz
    if(sizeIndex == s){
        bt2 = false;
    }
    if(sizeIndex != s){
        bt2 = true;
    }

    if(figureIndex <= 5 && (s >= 9 || s < 3) && s != 0){
        QMessageBox::information(nullptr, "ERROR", "WITH THIS FIGURE, CHOOSE ANOTHER CHESSBOARD SIZE. MINIMUM 3, MAXIMUM 8 !");
        size->setText("");
        ok = false;
    }
    if(figureIndex == 6 && (s < 10 || s > 13) && s != 0 && s != 1){
        QMessageBox::information(nullptr, "ERROR", "WITH THIS FIGURE(QUEEN ON KNIGHT), CHOOSE ANOTHER CHESSBOARD SIZE. MINIMUM 10, MAXIMUM 13 !");
        size->setText("");
        ok = false;
    }
    if(figureIndex == 7 && (s < 3 || s > 10) && s != 0 && s != 1){
        QMessageBox::information(nullptr, "ERROR", "WITH THIS FIGURE(KING ON KNIGHT), CHOOSE ANOTHER CHESSBOARD SIZE. MINIMUM 3, MAXIMUM 10 !");
        size->setText("");
        ok = false;
    }
    if(figureIndex == 8 && (s < 3 || s > 10) && s != 0 && s != 1){
        QMessageBox::information(nullptr, "ERROR", "WITH THIS FIGURE(ROOK ON KNIGHT), CHOOSE ANOTHER CHESSBOARD SIZE. MINIMUM 3, MAXIMUM 10 !");
        size->setText("");
        ok = false;
    }
    if(figureIndex == 9 && (s < 3 || s > 10) && s != 0 && s != 1){
        QMessageBox::information(nullptr, "ERROR", "WITH THIS FIGURE(BISHOP ON KNIGHT), CHOOSE ANOTHER CHESSBOARD SIZE. MINIMUM 3, MAXIMUM 10 !");
        size->setText("");
        ok = false;
    }
    if(size->text() == ""){
        startBtn->setEnabled(false); //nem lehet a start gombot megnyomni ha helytelen a size
    }
    if(s != 0 && s != 1 && ok){
        startBtn->setEnabled(true);
        previousBtn->setEnabled(btnClickable);
        nextBtn->setEnabled(btnClickable);

        variantNumber = 1;
        variantNumberLcd->display(QString::number(variantNumber));

        for(int i = 1 ; i <= chessBoardSize ; ++i)
            for(int j = 1 ; j <= chessBoardSize ; ++j)
                delete buttons[i][j];

        chessBoardSize = s;
        sizeIndex = s;

        if(chessBoardSize <= 8){
            firstUrl = secondUrl;
            switch(figureIndex){
                case 1:
                    backgroundFigure = "queenB.png);";
                    break;
                case 2:
                    backgroundFigure = "kingB.png);";
                    break;
                case 3:
                    backgroundFigure = "rookB.png);";
                    break;
                case 4:
                    backgroundFigure = "horseB.png);";
                    break;
                case 5:
                    backgroundFigure = "bishopB.png);";
                    break;
                case 6:
                    backgroundFigure = "queenB.png);";
                    break;
                case 7:
                    backgroundFigure = "kingB.png);";
                    break;
                case 8:
                    backgroundFigure = "rookB.png);";
                    break;
                case 9:
                    backgroundFigure = "bishopB.png);";
                    break;
            }
        }

        if(chessBoardSize > 8){
            firstUrl = secondUrl;
            switch(figureIndex){
                case 1:
                    backgroundFigure = "queenB2.png);";
                    break;
                case 2:
                    backgroundFigure = "kingB2.png);";
                    break;
                case 3:
                    backgroundFigure = "rookB2.png);";
                    break;
                case 4:
                    backgroundFigure = "horseB2.png);";
                    break;
                case 5:
                    backgroundFigure = "bishopB2.png);";
                    break;
                case 6:
                    backgroundFigure = "queenB2.png);";
                    break;
                case 7:
                    backgroundFigure = "kingB2.png);";
                    break;
                case 8:
                    backgroundFigure = "rookB2.png);";
                    break;
                case 9:
                    backgroundFigure = "bishopB2.png);";
                    break;
            }
        }
        finalUrl = firstUrl.append(backgroundFigure);

        if(bt1 || bt2){
            variantsTable->figureOrSizeChanged(chessBoardSize, numOfVariants);
        }
        checkNumberOfVariants();

        if(bt1 || bt2){
            backTracking(); //uj figura vagy tabla eseten backtrack
        }

        generateGrid();
        //gridLayout->setContentsMargins((9-s)*40,0,(9-s)*40,0);
    }
}

void TeacherChess::onPreviousButtonClicked(){
    //eloszor racs torlese, utanna az elozo variacio felhelyezese
    if(variantNumber > 1){
        for(int i = 1 ; i <= chessBoardSize ; ++i){
            for(int j = 1 ; j <= chessBoardSize ; ++j){
                if(checkColor(i,j) == 1){
                    setBackground(i, j, whiteColor, "");
                }
                if(checkColor(i,j) == -1){
                    setBackground(i, j, blackColor, "");
                }
            }
        }
        --variantNumber;
        variantNumberLcd->display(QString::number(variantNumber));
        printVariant(variantNumber);
    }
}

void TeacherChess::onNextButtonClicked(){
    //eloszor racs torlese, utanna a kovetkezo variacio felhelyezese
    if(variantNumber < numOfVariants){
        for(int i = 1 ; i <= chessBoardSize ; ++i){
            for(int j = 1 ; j <= chessBoardSize ; ++j){
                if(checkColor(i,j) == 1){
                    setBackground(i, j, whiteColor, "");
                }
                if(checkColor(i,j) == -1){
                    setBackground(i, j, blackColor, "");
                }
            }
        }
        ++variantNumber;
        variantNumberLcd->display(QString::number(variantNumber));
        printVariant(variantNumber);
    }
}

void TeacherChess::onVisualizationButtonClicked(){
    Visualization *visualizationWindow = new Visualization(this, chessBoardSize, figureIndex); // atadtam a konstruktorban  a meretet es a figurat
    visualizationWindow->show();
    hide(); //regi window eltuntetese
}

void TeacherChess::onStartButtonClicked(){
    startBtn->setEnabled(false);
    previousBtn->setEnabled(!btnClickable);
    nextBtn->setEnabled(!btnClickable);
    visBtn->setEnabled(!btnClickable);

    variantNumber = 1;
    printVariant(variantNumber);  //elso variacio fehelyezese a racsra
    size->setText(QString::number(chessBoardSize));
}

void TeacherChess::printVariant(int v){
    for(int i = 1; i <= chessBoardSize; ++i){
        for(int j = 1; j <= chessBoardSize; ++j){
            if(variantsTable->getContent(i, j, v) == 1){
                setFinalBackground(i, j);
            }
        }
    }
}

void TeacherChess::checkNumberOfVariants(){
    if(figureIndex == 1){
        maxNumText->setText("N");
        switch(chessBoardSize){
        case 8:
            numOfVariants = 92;
            numberOfVariants->display(QString::number(numOfVariants));
            break;
        case 7:
            numOfVariants = 40;
            numberOfVariants->display(QString::number(numOfVariants));
            break;
        case 6:
            numOfVariants = 4;
            numberOfVariants->display(QString::number(numOfVariants));
            break;
        case 5:
            numOfVariants = 10;
            numberOfVariants->display(QString::number(numOfVariants));
            break;
        case 4:
            numOfVariants = 2;
            numberOfVariants->display(QString::number(numOfVariants));
            break;
        case 3:
            numOfVariants = 0;
            numberOfVariants->display(QString::number(numOfVariants));
            break;
        }
    }
    if(figureIndex == 2){
        if(chessBoardSize % 2 != 0){
            maxNumText->setText("(N^2 + 2*N + 1)/4");
            numOfVariants = 1;
            numberOfVariants->display(QString::number(numOfVariants));
        }
        else{
            maxNumText->setText("N*N/4");
            if(chessBoardSize == 4){
                numOfVariants = 79;
                numberOfVariants->display(QString::number(numOfVariants));
            }
            if(chessBoardSize == 6){
                numOfVariants = 3600;
                numberOfVariants->display(QString::number(numOfVariants));
            }
            if(chessBoardSize == 8){
                numOfVariants = 281571;
                numberOfVariants->display(QString::number(numOfVariants));
            }
        }
    }
    if(figureIndex == 3){
        maxNumText->setText("N");
        switch(chessBoardSize){
        case 8:
            numOfVariants = 40320;
            numberOfVariants->display(QString::number(numOfVariants));
            break;
        case 7:
            numOfVariants = 5040;
            numberOfVariants->display(QString::number(numOfVariants));
            break;
        case 6:
            numOfVariants = 720;
            numberOfVariants->display(QString::number(numOfVariants));
            break;
        case 5:
            numOfVariants = 120;
            numberOfVariants->display(QString::number(numOfVariants));
            break;
        case 4:
            numOfVariants = 24;
            numberOfVariants->display(QString::number(numOfVariants));
            break;
        case 3:
            numOfVariants = 6;
            numberOfVariants->display(QString::number(numOfVariants));
            break;
        }
    }
    if(figureIndex == 4){
        if(chessBoardSize % 2 == 0){
            maxNumText->setText("N*N/2");
            numOfVariants = 2;
            numberOfVariants->display(QString::number(numOfVariants));
        }
        if(chessBoardSize % 2 != 0){
            maxNumText->setText("(N*N+1)/2");
            numOfVariants = 1;
            numberOfVariants->display(QString::number(numOfVariants));
        }
    }
    if(figureIndex == 5){
        maxNumText->setText("2*(N-1)");
        numOfVariants = pow(2, chessBoardSize);
        numberOfVariants->display(QString::number(numOfVariants));
    }
    if(figureIndex == 6){
        maxNumText->setText("N");
        if(chessBoardSize == 10){
            numOfVariants = 4;
            numberOfVariants->display(QString::number(numOfVariants));
        }
        if(chessBoardSize == 11){
            numOfVariants = 44;
            numberOfVariants->display(QString::number(numOfVariants));
        }
        if(chessBoardSize == 12){
            numOfVariants = 156;
            numberOfVariants->display(QString::number(numOfVariants));
        }
        if(chessBoardSize == 13){
            numOfVariants = 1876;
            numberOfVariants->display(QString::number(numOfVariants));
        }
    }
    if(figureIndex == 7){
        if(chessBoardSize == 4){
            numOfVariants = 25;
            numberOfVariants->display(QString::number(numOfVariants));
        }
        if(chessBoardSize == 6){
            numOfVariants = 120;
            numberOfVariants->display(QString::number(numOfVariants));
        }
        if(chessBoardSize == 8){
            numOfVariants = 497;
            numberOfVariants->display(QString::number(numOfVariants));
        }
        if(chessBoardSize == 10){
            numOfVariants = 1924;
            numberOfVariants->display(QString::number(numOfVariants));
        }
        if(chessBoardSize % 2 != 0){
            maxNumText->setText("(N^2 + 2*N + 1)/4");
            numOfVariants = 1;
            numberOfVariants->display(QString::number(numOfVariants));
        }
        if(chessBoardSize % 2 == 0){
            maxNumText->setText("N*N/4");
        }
    }
    if(figureIndex == 8){
        maxNumText->setText("N");
        if(chessBoardSize == 3){
            numOfVariants = 2;
            numberOfVariants->display(QString::number(numOfVariants));
        }
        if(chessBoardSize == 4){
            numOfVariants = 8;
            numberOfVariants->display(QString::number(numOfVariants));
        }
        if(chessBoardSize == 5){
            numOfVariants = 20;
            numberOfVariants->display(QString::number(numOfVariants));
        }
        if(chessBoardSize == 6){
            numOfVariants = 94;
            numberOfVariants->display(QString::number(numOfVariants));
        }
        if(chessBoardSize == 7){
            numOfVariants = 438;
            numberOfVariants->display(QString::number(numOfVariants));
        }
        if(chessBoardSize == 8){
            numOfVariants = 2766;
            numberOfVariants->display(QString::number(numOfVariants));
        }
        if(chessBoardSize == 9){
            numOfVariants = 19480;
            numberOfVariants->display(QString::number(numOfVariants));
        }
        if(chessBoardSize == 10){
            numOfVariants = 163058;
            numberOfVariants->display(QString::number(numOfVariants));
        }
    }
    if(figureIndex == 9){
        numOfVariants = pow(2, chessBoardSize) / 4;
        numberOfVariants->display(QString::number(numOfVariants));
    }
}

void TeacherChess::generateKnight(){
    for(int k = 1 ; k <= numOfVariants ; ++k){
        for(int i = 1 ; i <= chessBoardSize ; ++i){
            for(int j = 1 ; j <= chessBoardSize ; ++j){
                if(k == 1){
                    if(checkColor(i, j) == 1){
                        variantsTable->setContent(i, j, k);
                    }
                }
                if(k == 2 && chessBoardSize % 2 == 0){ // csak akkor ha paros a sakktabla merete , ha paratlan csak a feherekre lehet helyezni
                    if(checkColor(i, j) == -1){
                        variantsTable->setContent(i, j, k);
                    }
                }
            }
        }
    }
}

void TeacherChess::backTracking(){
    lvl = 1;
    if(figureIndex == 1){
       bt_chess(array, chessBoardSize, 1, queen_attack);
    }
    if(figureIndex == 2){
        q = 0;
        if(chessBoardSize % 2 != 0){
            for(int i = 1; i <= chessBoardSize; ++i){
                for(int j = 1; j <= chessBoardSize; ++j){
                    if(i % 2 != 0 && j % 2 != 0){
                        variantsTable->setContent(i, j, 1);
                    }
                }
            }
        }
        if(chessBoardSize % 2 == 0){
            bt_king(0, 0, 1, 1);
        }
    }
    if(figureIndex == 3){
       bt_chess(array, chessBoardSize, 1, rook_attack);
    }
    if(figureIndex == 4){
        generateKnight();
    }
    if(figureIndex == 5){
        firstCreate();
        solveBishop();
        printTable1();
    }
    if(figureIndex == 6){
       bt_chess(array, chessBoardSize, 1, queenOnKnight_attack);
    }
    if(figureIndex == 7){
        q = 0;
        if(chessBoardSize % 2 != 0){
            for(int i = 1; i <= chessBoardSize; ++i){
                for(int j = 1; j <= chessBoardSize; ++j){
                    if(i % 2 != 0 && j % 2 != 0){
                        variantsTable->setContent(i, j, 1);
                    }
                }
            }
        }
        if(chessBoardSize % 2 == 0){
            bt_king(0, 0, 1, 1);
        }
    }
    if(figureIndex == 8){
       bt_chess(array, chessBoardSize, 1, rookOnKnight_attack);
    }
    if(figureIndex == 9){
        t = 0;
        firstCreate();
        solveBishop();
        bishopOnKnightTest();
    }
}

//-----------------------------------  XCode BACKTRACKING C++  -------------------------------------------------

//compare fuggvenyek
int TeacherChess::queen_attack(int i1, int j1, int i2, int j2){
    //sor, oszlop, atlo
    return i1 == i2 || j1 == j2 || abs(i1-i2) == abs(j1-j2);
}

int TeacherChess::rook_attack(int i1, int j1, int i2, int j2){
    //sor, oszlop
    return i1 == i2 || j1 == j2;
}

int TeacherChess::queenOnKnight_attack(int i1, int j1, int i2, int j2){
    //sor, oszlop, atlo, lo
    return i1 == i2 || j1 == j2 || abs(i1-i2) == abs(j1-j2) || (abs(i1-i2) == 1 && abs(j1-j2) == 2) || (abs(i1-i2) == 2 && abs(j1-j2) == 1);
}

int TeacherChess::rookOnKnight_attack(int i1, int j1, int i2, int j2){
    //sor, oszlop, lo
    return i1 == i2 || j1 == j2 || (abs(i1-i2) == 1 && abs(j1-j2) == 2) || (abs(i1-i2) == 2 && abs(j1-j2) == 1);
}

int TeacherChess::itIsOk1(int *x, int k, int (*figure_attack)(int,int,int,int)){
    for( int i = 1 ; i < k ; ++i ){
        if (figure_attack(i, x[i], k, x[k])) { return 0; }
    }
    return 1;
}

void TeacherChess::print(int *x, int n){
    for( int i = 1 ; i <= n ; ++i ){
        //printf("(%i,%i)", i, x[i]);
        variantsTable->setContent(i, x[i], lvl); // a 3D tombben valo elhelyezes, variaciok szintenken (lvl)
    }
    //printf("\n");
}

void TeacherChess::bt_chess(int *x, int n, int k, int (*figure_attack)(int,int,int,int)){
    ct = 0;
    for( x[k] = 1; x[k] <= n ; ++x[k] ){
        if( itIsOk1(x, k, figure_attack) ){
            if( k == n ){
                print(x, k);
                lvl++;
                ct++;
            }
            else{
                bt_chess(x, n, k+1, figure_attack);
            }
        }
    }
}
// --------------------- King BT ----------------------

void TeacherChess::printKing(){
    ++q;
    for( int i = 0; i < chessBoardSize ; ++i ){
        for( int j = 0; j < chessBoardSize ; ++j ){
            if(tabla[i][j] == 1){
                variantsTable->setContent(i+1, j+1, q);
            }
            //cout << desk[i][j] <<" ";
        }
        //cout << endl;
    }
    //cout << endl;
}

int TeacherChess::itIsOk2( int x, int y){
    for( int i = -1; i <= 1 ; ++i ){
        for( int j = -1; j <= 1 ; ++j ){
            if( i == 0 && j == 0 ){ continue; }
            if( x+i < 0 || x+i >= chessBoardSize || y+j < 0 || y+j >= chessBoardSize ){ continue; }
            if( tabla[x+i][y+j] == 1 ){
                return 0;
            }
        }
    }
    //ha a kiraly a lovon van
    if(figureIndex == 7){
        for (int i = 0; i < chessBoardSize; ++i) {
                for (int j = 0; j < chessBoardSize; ++j) {
                    if(tabla[i][j] == 1){
                        if((abs(i-x) == 1 && abs(j-y) == 2) || (abs(i-x) == 2 && abs(j-y) == 1)){
                            return 0;
                        }
                    }
                }
            }
    }
    return 1;
}

void TeacherChess::bt_king(int ii, int jj, int k, int q){
    for( int i = 0; i < 2 ; ++i ){
        for( int j = 0; j < 2 ; ++j ){
            if( itIsOk2(ii+i,jj+j) ){
                tabla[ii+i][jj+j] = 1;
                if( k == chessBoardSize*chessBoardSize/4 ){
                    printKing();
                }
                else{
                    if( jj+2 < chessBoardSize ){
                        bt_king(ii, jj+2, k+1, q);
                    }
                    else{
                        bt_king(ii+2, 0, k+1, q);
                    }
                }
                tabla[ii+i][jj+j] = 0;
            }
        }
    }
}

// --------------------- Bishop BT ----------------------

int db=0;

void TeacherChess::printBishop(){
    cout << ++db << ":\n";
    ++q;
    for( int i = 0; i < chessBoardSize ; ++i ){
        for( int j = 0; j < chessBoardSize ; ++j ){
            if(tabla[i][j] == 1){
                variantsTable->setContent(i+1, j+1, q);
            }
            //cout << tabla[i][j] << ' ';
        }
        //cout << endl;
    }
    //cout << endl;

}

int TeacherChess::itIsOk3( int x, int y){
    for( int i = 0; i < chessBoardSize ; ++i ){
        for( int j = 0; j < chessBoardSize ; ++j ){
            if( (x-y == i-j || x+y == i+j) && tabla[i][j] == 1 ){
                return 0;
            }
            if( figureIndex == 9 && ((abs(i-x) == 1 && abs(j-y) == 2) || (abs(i-x) == 2 && abs(j-y) == 1)) && tabla[i][j] == 1){
                return 0;
            }
        }
    }
    return 1;
}

void TeacherChess::bt_bishop(int atlo, int k){
    for( int i = 0; i < chessBoardSize ; ++i ){
        for( int j = 0; j < chessBoardSize ; ++j ){
            if(i+j == atlo){
                if( itIsOk3(i, j) ){

                    tabla[i][j] = 1;

                    if( k == 2*(chessBoardSize-1) ){
                        printBishop();
                    }
                    else{
                        bt_bishop(atlo+1, k+1);
                    }

                    tabla[i][j] = 0;
                }
            }
        }
    }
}

void TeacherChess::bt_bishop2(int atlo, int g){
    for( int i = chessBoardSize-1; i >= 0 ; --i ){
        for( int j = chessBoardSize-1; j >= 0 ; --j ){
            if(i+j == atlo){
                if( itIsOk3(i, j) ){

                    tabla[i][j] = 1;

                    if( g == 2*(chessBoardSize-1) ){
                        printBishop();
                    }
                    else{
                        bt_bishop2(atlo-1, g+1);
                    }

                    tabla[i][j] = 0;
                }
            }
        }
    }
}

// --------------------- Bishop binary ----------------------

void TeacherChess::printTable1(){
    for (int k = 0; k < var; ++k) {
        cout<<k<<":"<<endl;
        for( int i = 0; i < n ; ++i ){
            for( int j = 0; j < n ; ++j ){
                if(tabla1[i][j][k] == 1){
                    variantsTable->setContent(i+1, j+1, k+1);
                }
                //cout << tabla1[i][j][k] << ' ';
            }
            //cout << endl;
        }
        //cout << endl;
    }
}

void TeacherChess::printOneSolution(int k){
    cout<<++t<<":"<<endl;
    for( int i = 0; i < n ; ++i ){
        for( int j = 0; j < n ; ++j ){
            if(tabla1[i][j][k] == 1){
                variantsTable->setContent(i+1, j+1, t);
            }
            //cout << tabla1[i][j][k] << ' ';
        }
        //cout << endl;
    }
    //cout << endl;
}

void TeacherChess::decToBinary(int a)
{
    int s=-1;
    for(int i=0; i<=32; ++i){
        binaryNum[i] = 0;
        vegso[i] = 0;
    }
    int i = 0;
    while (a > 0) {
        binaryNum[i] = a % 2;
        a = a / 2;
        i++;
    }

    for (int j = n - 1; j >= 0; j--){
        //cout << binaryNum[j];
        vegso[++s] = binaryNum[j];
    }
}

void TeacherChess::firstCreate(){
    t = 0;
    n = chessBoardSize;
    var = pow(2, n);

    for (int k = 0; k < var; ++k) {
        for( int i = 0; i < n ; ++i ){
            for( int j = 0; j < n ; ++j ){
                tabla1[i][j][k] = 0;
            }
        }
    }

    for (int k = 0; k < var; ++k) {
        for( int i = 0; i < n ; ++i ){
            for( int j = 0; j < n ; ++j ){
                decToBinary(k);
                if (i == n-1) {
                    tabla1[i][j][k] = vegso[j];
                }
            }
        }
    }
}

void TeacherChess::solveBishop(){
    for (int k = 0; k < var; ++k) {
        for( int i = 0; i < n ; ++i ){
            for( int j = 0; j < n ; ++j ){
                if(i == n-1){
                    if(tabla1[i][j][k] == 1 && j != 0 && j != n-1){
                        tabla1[0][n-1-j][k] = 1;
                    }

                    if(tabla1[i][j][k] == 0){
                        if(j != 0){
                            tabla1[n-1-j][0][k] = 1;
                        }
                        if(j != n-1){
                            tabla1[j][n-1][k] = 1;
                        }
                    }
                }
            }
        }
    }
}

void TeacherChess::bishopOnKnightTest(){
    int d = 0;
    bool ok;
    for (int k = 0; k < var; ++k) {
        ok =  true;
        for( int i1 = 0; i1 < n ; ++i1 ){
            for( int j1 = 0; j1 < n ; ++j1 ){
                //bal felso sarok
                if((tabla1[0][1][k] == 1 && tabla1[2][0][k] == 1) || (tabla1[0][2][k] == 1 && tabla1[1][0][k] == 1)){
                    ok = false;
                }
                //jobb felso sarok
                if((tabla1[0][n-2][k] == 1 && tabla1[2][n-1][k] == 1) || (tabla1[0][n-3][k] == 1 && tabla1[1][n-1][k] == 1)){
                    ok = false;
                }
                //bal also sarok
                if((tabla1[n-1][1][k] == 1 && tabla1[n-3][0][k] == 1) || (tabla1[n-1][2][k] == 1 && tabla1[n-2][0][k] == 1)){
                    ok = false;
                }
                //jobb also sarok
                if((tabla1[n-1][n-2][k] == 1 && tabla1[n-3][n-1][k] == 1) || (tabla1[n-1][n-3][k] == 1 && tabla1[n-2][n-1][k] == 1)){
                    ok = false;
                }
            }
        }
        if(ok){
            ++d;
            printOneSolution(k);
            //kiir k-adik variacio, kell egy ilyen fuggveny es akkor be tudom tenni a variantsTable-be(szoftverbe)!
        }
    }
    cout<<"Futo a lovon problema, helyes megoldasok szama(2^n / 4): "<<d<<endl;
}
